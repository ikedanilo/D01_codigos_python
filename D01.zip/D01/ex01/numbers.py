def opentxt(arquivo):
  with open(arquivo, "r") as file:
    leitura = file.read()
    lista = leitura.split(",")
  printlista(lista)

def printlista(lista):
  for n in lista:
    print(n)

if __name__ == '__main__':
  opentxt('numbers.txt')
