def ler_txt():
  dicionario = {}
  lista_geral = []
  
  with open('periodic_table.txt', 'r') as file:
    linhas = file.readlines()

  for l in linhas:
    l_temp = l.split(",")
    l_temp2 = l_temp[1:]
    l_temp1 = l_temp[0].split("=")
    l_final = l_temp1 + l_temp2
    lista_geral.append(l_final)

  print(lista_geral)
  return lista_geral


def gera_html():
  with open("arquivo.html", "w+") as file:
    file.write(f"<!DOCTYPE html>\n")
    file.write(f"<html lang="en">\n")
    file.write(f"<head>\n")
    file.write(f"  <meta charset="UTF-8">\n")
    file.write(f"  <meta http-equiv="X-UA-Compatible" content="IE=edge">"\n")
    file.write(f"  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n")
    file.write(f"  <title>Document</title>\n")
    file.write(f"</head>\n")
    file.write(f"<body>\n")
    file.write(f"\n")
    file.write(f"</body>\n")
    file.write(f"</html>\n")


if __name__ == '__main__':
  ler_txt()
  gera_html()


