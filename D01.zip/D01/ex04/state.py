import sys

def estado(parametro):
  total_parametros = len(parametro)
  
  if total_parametros == 2:
    capital = parametro[1]

    states = {
    "Oregon" : "OR",
    "Alabama" : "AL",
    "New Jersey": "NJ",
    "Colorado" : "CO"
    }

    capital_cities = {
    "OR": "Salem",
    "AL": "Montgomery",
    "NJ": "Trenton",
    "CO": "Denver"
    }

    # estado = 'Alabama'  # INPUT
    lista_capital= []

    for v in capital_cities.values():
      lista_capital.append(v)

    if capital in lista_capital:
      for k, v in capital_cities.items():
        if capital == v:
          sigla = k
          for x, y in states.items():
            if y == sigla:
              print(x)
    else:
      print("Unknown capital city")


if __name__ == '__main__':
  estado(sys.argv)
