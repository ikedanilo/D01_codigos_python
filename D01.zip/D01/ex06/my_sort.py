def sort():
  d = {
  'Hendrix' : '1942',
  'Allman' : '1946',
  'King' : '1925',
  'Clapton' : '1945',
  'Johnson' : '1911',
  'Berry' : '1926',
  'Vaughan' : '1954',
  'Cooder' : '1947',
  'Page' : '1944',
  'Richards' : '1943',
  'Hammett' : '1962',
  'Cobain' : '1967',
  'Garcia' : '1942',
  'Beck' : '1944',
  'Santana' : '1947',
  'Ramone' : '1948',
  'White' : '1975',
  'Frusciante': '1970',
  'Thompson' : '1949',
  'Burton' : '1939'
  }

  d_new = {}
  # Pegando ano e transformando e lista (ano sem repetição)
  lista_ano = []
  for v in d.values():
    if v not in lista_ano:
      lista_ano.append(v)
  
  # Organizando ano em ordem crescente
  lista_ano.sort()

  # Criando dicionario keys (ano) x values (musico)
  lista_nome_temp = []
  dicionario_ano_musico = {}
  for ano in lista_ano:
    for k, v in d.items():
      if ano == v:
        lista_nome_temp.append(k)
    lista_nome_temp = sorted(lista_nome_temp)
    dicionario_ano_musico[ano] = lista_nome_temp.copy()
    lista_nome_temp.clear()

  return dicionario_ano_musico


def escreva():
  dicionario_ano_musico = sort()
  for l in dicionario_ano_musico.values():
    for v in l:
      print(v)

if __name__ == '__main__':
  escreva()
