def my_var():
  entrada = 42
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = '42'
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = 'quarante-deux'
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = 42.0
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = True
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = [42]
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = {42: 42}
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = (42,)
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

  entrada = set()
  tipo = type(entrada)
  print(f"{entrada} has a type {tipo}")

if __name__ == '__main__':
  my_var()
