#!python3

import sys

def dic_estado_capital():
  dic_new = {}

  states = {
  "Oregon" : "OR",
  "Alabama" : "AL",
  "New Jersey": "NJ",
  "Colorado" : "CO"
  }

  capital_cities = {
  "OR": "Salem",
  "AL": "Montgomery",
  "NJ": "Trenton",
  "CO": "Denver"
  }

  for e, sx in states.items(): 
    for sy, c in capital_cities.items():
      if sx == sy:
        dic_new[f"{e}"] = c

  return dic_new

def chk_estado_capital(argumento):
  entrada = argumento
  # entrada = "New Jersey, Tren ton, NewJersey, Trenton, toto,   ,   sAlem"
  lista_estado_capital = entrada.split(", ")
  lista_estado_capital = retira_esp_esq_branco(lista_estado_capital)

  dic_new = dic_estado_capital()

  for v in lista_estado_capital:
    chk_v_vazio = v.strip()
    if chk_v_vazio != "":
      v_new = v.title()
      if v_new in dic_new.keys() or v_new in dic_new.values():
        for e, c in dic_new.items():
          if v_new == e:
            print(f"{c} is the capital of {v_new}")
          elif v_new == c:
            print(f"{v_new} is the capital of {e}")
      else:
        print(f"{v} is neither a capital city nor a state")


def retira_esp_esq_branco(lista):
  nova_lista = []
  for v in lista:
    v = v.lstrip()
    nova_lista.append(v)
  return nova_lista


if __name__ == '__main__':
  entrada = sys.argv[1]
  chk_estado_capital(entrada)
