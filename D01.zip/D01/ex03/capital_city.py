import sys

def capital(parametros):
  total_parametros = len(parametros)
  
  if total_parametros == 2:
    estado = parametros[1]

    states = {
    "Oregon" : "OR",
    "Alabama" : "AL",
    "New Jersey": "NJ",
    "Colorado" : "CO"
    }

    capital_cities = {
    "OR": "Salem",
    "AL": "Montgomery",
    "NJ": "Trenton",
    "CO": "Denver"
    }

    # estado = 'Alabama'  # INPUT
    lista_estado = []

    for k in states.keys():
      lista_estado.append(k)

    if estado in lista_estado:
      for k, v in states.items():
        if estado == k:
          sigla = v
          for x, y in capital_cities.items():
            if x == sigla:
              print(y)
    else:
      print("Unknown state")


if __name__ == '__main__':
  capital(sys.argv)
